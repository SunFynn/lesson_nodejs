module.exports = {
    url: "mongodb://mongo:27017",
    dbName: 'taro',
}